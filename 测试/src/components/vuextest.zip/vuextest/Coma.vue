<template>
    <div>
        我是coma组件
        <h3>{{count}}</h3>
        <p>{{$store.getters.mytest}}</p>
        <button @click="changeState(3)">点击我数量加加</button>
    </div>
</template>

<script>
    import { mapState } from 'vuex';
    import { mapActions } from 'vuex'
    export default {
        name: "",
        methods:{
            // changeState(){
            //     // this.$store.commit("add",2,3);
            //     this.$store.dispatch('add',3);
            //
            // }
            ...mapActions({changeState:'add'})
        },
        computed:{
            ...mapState(['count'])
        }

    }
</script>

<style scoped>

</style>