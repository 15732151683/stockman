<?php
	//在用户授权后，获得code
	$code = $_GET["code"];
	echo $code;
?>