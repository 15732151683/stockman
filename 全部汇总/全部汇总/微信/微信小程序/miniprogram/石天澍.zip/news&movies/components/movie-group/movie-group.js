// components/movie-group/movie-group.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    movies:{
      type:Array
    },
    movieGroup:{
      type:Object
    }
  },

  /**
   * 组件的初始数据
   */
  data: {

  },

  /**
   * 组件的方法列表
   */
  methods: {
    goToDetail:function(e){
      var movieId = e.currentTarget.dataset.movieId;
      // console.log(movieId);
      wx.navigateTo({
        url: '/pages/movies/movie-detail/movie-detail?movieId='+movieId
      })
    },
    goToMore:function(e){
      var title = e.currentTarget.dataset.title;
      var key = e.currentTarget.dataset.key;
      wx.navigateTo({
        url: `/pages/movies/movie-more/movie-more?title=${title}&key=${key}`,
      })
    }
  }
})
