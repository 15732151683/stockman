<?php
/**
阿进Qq2474748915
该版权死全家
**/
$dbconfig=array(
	'host' => 'localhost', //数据库服务器
	'port' => 3306, //数据库端口
	'user' => 'daoajzzt', //数据库用户名
	'pwd' => 'rbYW63jyAW', //数据库密码
	'dbname' => 'daoajzzt' //数据库名
);
?>