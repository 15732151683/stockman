<?php
/**
阿进Qq2474748915
该版权死全家
**/
$mod='blank';
include("../includes/common.php");
$title='分站管理';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">后台管理</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li>  <a href="./"><span class="glyphicon glyphicon-user"></span> 平台首页</a>
          </li>
		 <li> <a href="./set.php"><span class="glyphicon glyphicon-cog"></span> 系统设置</a></li>
 <li class="active"><a href="./sitelist.php"><span class="glyphicon glyphicon-cog"></span>分站管理</a></li>
<li><a href="./about.php"><span class="glyphicon glyphicon-ok"></span> 关于本程序</a> </li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:70px;">
    <div class="col-sm-12 col-md-10 center-block" style="float: none;">
<?php
function getkm($len = 18)
{
	$str = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
	$strlen = strlen($str);
	$randstr = "";
	for ($i = 0; $i < $len; $i++) {
		$randstr .= $str[mt_rand(0, $strlen - 1)];
	}
	return $randstr;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add')
{
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">添加分站</h3></div>';
echo '<div class="panel-body">';
echo '<form action="./sitelist.php?my=add_submit" method="POST">
<div class="form-group">
<label>*绑定域名:</label><br>
<input type="text" class="form-control" name="url" value="" required>
<font color="green">绑定多个域名请用英文逗号,隔开！</font>
</div>
<div class="form-group">
<label>*管理员用户名:</label><br>
<input type="text" class="form-control" name="user" value="" required>
</div>
<div class="form-group">
<label>*管理员密码:</label><br>
<input type="text" class="form-control" name="pwd" value="" required>
</div>
<div class="form-group">
<label>*过期时间:</label><br>
<input type="text" id="d11" class="form-control Wdate" name="date" value="" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
</div>
<div class="form-group">
<label>*是否激活:</label><br><select class="form-control" name="active"><option value="1">1_激活</option><option value="0">0_封禁</option></select>
</div>
<div class="form-group">
<label>备注信息:</label><br>
<textarea class="form-control" name="note" rows="3" placeholder="仅用于备注"></textarea>
</div>
<input type="submit" class="btn btn-primary btn-block"
value="确定添加"></form>';
echo '<br/><a href="./sitelist.php">>>返回分站管理</a>';
echo '</div></div>';
}
elseif($my=='edit')
{
$id=$_GET['id'];
$row=$DB->get_row("select * from quan_config where id='$id' limit 1");
echo '<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">修改分站信息</h3></div>';
echo '<div class="panel-body">';
echo '<form action="./sitelist.php?my=edit_submit&id='.$id.'" method="POST">
<div class="form-group">
<label>*绑定域名:</label><br>
<input type="text" class="form-control" name="url" value="'.$row['url'].'" required>
<font color="green">绑定多个域名请用英文逗号,隔开！</font>
</div>
<div class="form-group">
<label>*过期时间:</label><br>
<input type="text" id="d11" class="form-control Wdate" name="date" value="'.$row['date'].'" onClick="WdatePicker({isShowClear:false})" autocomplete="off" required>
</div>
<div class="form-group">
<label>*是否激活:</label><br><select class="form-control" name="active" default="'.$row['active'].'"><option value="1">1_激活</option><option value="0">0_封禁</option></select>
</div>
<div class="form-group">
<label>备注信息:</label><br>
<textarea class="form-control" name="note" rows="3" placeholder="仅用于备注">'.$row['note'].'</textarea>
</div>
<input type="submit" class="btn btn-primary btn-block"
value="确定修改"></form>
';
echo '<br/><a href="./sitelist.php">>>返回分站管理</a>';
echo '</div></div>
<script>
var items = $("select[default]");
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default"));
}
</script>';
}
elseif($my=='add_submit')
{
$url=$_POST['url'];
$user=$_POST['user'];
$pwd=$_POST['pwd'];
$date=$_POST['date'];
$active=$_POST['active'];
$note=$_POST['note'];
if($url==NULL or $date==NULL){
showmsg('保存错误,请确保加*项都不为空!',3);
} else {
$sqls="INSERT INTO `quan_config`(`switch`, `user`, `pwd`, `sitename`, `keywords`, `description`, `kfqq`, `buy`, `active`, `url`, `date`, `note`) VALUES ('1', '{$user}', '{$pwd}', '久念圈圈助手', '久念圈圈助手,圈圈赞,圈圈赞99+', '久念圈圈助手,一键为你的QQ拉满圈圈赞99+', '1653408521', 'http://www.917ka.com/', '{$active}', '{$url}', '{$date}', '{$note}')";
$siteid=$DB->insert($sqls);
$urls=explode(',',$url);
foreach($urls as $row){
	if($row==$_SERVER['HTTP_HOST'])showmsg('不能将主站域名绑定到分站!',3);
	$DB->query("REPLACE INTO quan_domain SET siteid='$siteid',domain='$row'");
}
if($siteid){
	showmsg('新增分站成功！<br/>请将该分站的域名解析到本站服务器，并添加授权，即可访问。<br/><br/><a href="./sitelist.php">>>返回分站管理</a>',1);
}else
	showmsg('新增分站失败！<br/>错误信息：'.$error.$DB->error(),4);
}
}
elseif($my=='edit_submit')
{
$id=$_GET['id'];
$rows=$DB->get_row("select * from quan_config where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$url=$_POST['url'];
$date=$_POST['date'];
$active=$_POST['active'];
$note=$_POST['note'];
if($url==NULL or $date==NULL){
showmsg('保存错误,请确保加*项都不为空!',3);
} else {
$sql="update `quan_config` set `url` ='$url',`date` ='$date',`active` ='$active',`note` ='$note' where `id`='$id'";
$urls=explode(',',$url);
foreach($urls as $row)
	$DB->query("REPLACE INTO quan_domain SET siteid='$id',domain='$row'");
if($DB->query($sql))
	showmsg('修改分站成功！<br/><br/><a href="./sitelist.php">>>返回分站管理</a>',1);
else
	showmsg('修改分站失败！'.$DB->error(),4);
}
}
elseif($my=='delete')
{
$id=$_GET['id'];
if($id==1)
	showmsg('无法删除主站！',3);
$rows=$DB->get_row("select * from quan_config where id='$id' limit 1");
if(!$rows)
	showmsg('当前记录不存在！',3);
$urls=explode(',',$rows['url']);
$DB->query("DELETE FROM quan_domain WHERE siteid='{$id}'");
$sql="DELETE FROM quan_config WHERE id='$id'";
if($DB->query($sql))
	showmsg('删除分站成功！<br/><br/><a href="./sitelist.php">>>返回分站管理</a>',1);
else
	showmsg('删除分站失败！'.$DB->error(),4);
}
else
{

$numrows=$DB->count("SELECT count(*) from quan_config WHERE id!=1");
$outdate=$DB->count("select count(*) from quan_config where date<$date and id!=1");
echo '<div class="alert alert-info">系统共有'.$numrows.'个分站，其中过期的分站有'.$outdate.'个。<br/>
<a href="./sitelist.php?my=add" class="btn btn-primary">添加一个分站</a>';
echo '</div>';

echo $con;
?>
      <div class="table-responsive">
        <table class="table table-striped">
          <thead><tr><th>ID</th><th>绑定域名</th><th>到期时间</th><th>状态</th><th>操作</th></tr></thead>
          <tbody>
<?php
$pagesize=30;
$pages=intval($numrows/$pagesize);
if ($numrows%$pagesize)
{
 $pages++;
 }
if (isset($_GET['page'])){
$page=intval($_GET['page']);
}
else{
$page=1;
}
$offset=$pagesize*($page - 1);

$rs=$DB->query("SELECT * FROM quan_config WHERE id!=1 order by id desc limit $offset,$pagesize");
while($res = $DB->fetch($rs))
{
if($res['isuse']==1) {
	$isuse='<font color="red">已使用</font><br/>使用者:'.$res['user'];
} elseif($res['isuse']==0) {
	$isuse='<font color="green">未使用</font>';
}
echo '<tr><td><b>'.$res['id'].'</b></td><td>'.$res['url'].'</td><td>'.$res['date'].'</td><td>'.($res['active']==1?'开启':'关闭').'</td><td><a href="./sitelist.php?my=edit&id='.$res['id'].'" class="btn btn-info btn-xs">编辑</a>&nbsp;<a href="./sitelist.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此分站吗？\');">删除</a></td></tr>';
}
?>
          </tbody>
        </table>
      </div>
<?php
echo'<ul class="pagination">';
$first=1;
$prev=$page-1;
$next=$page+1;
$last=$pages;
if ($page>1)
{
echo '<li><a href="sitelist.php?page='.$first.$link.'">首页</a></li>';
echo '<li><a href="sitelist.php?page='.$prev.$link.'">&laquo;</a></li>';
} else {
echo '<li class="disabled"><a>首页</a></li>';
echo '<li class="disabled"><a>&laquo;</a></li>';
}
for ($i=1;$i<$page;$i++)
echo '<li><a href="sitelist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '<li class="disabled"><a>'.$page.'</a></li>';
for ($i=$page+1;$i<=$pages;$i++)
echo '<li><a href="sitelist.php?page='.$i.$link.'">'.$i .'</a></li>';
echo '';
if ($page<$pages)
{
echo '<li><a href="sitelist.php?page='.$next.$link.'">&raquo;</a></li>';
echo '<li><a href="sitelist.php?page='.$last.$link.'">尾页</a></li>';
} else {
echo '<li class="disabled"><a>&raquo;</a></li>';
echo '<li class="disabled"><a>尾页</a></li>';
}
echo'</ul>';
#分页
}
?>
    </div>
  </div>
<script src="../assets/datepicker/WdatePicker.js"></script>