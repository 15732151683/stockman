
<?php
/**
阿进Qq2474748915
该版权死全家
**/
$mod='blank';
include("../includes/common.php");
$title='关于本程序';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">后台管理</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
  
<li>
            <a href="./"><span class="glyphicon glyphicon-user"></span> 平台首页</a>
          </li>
		  <li>
		  <li><a href="./set.php"><span class="glyphicon glyphicon-cog"></span> 系统设置</a></li>
 <li><a href="./sitelist.php"><span class="glyphicon glyphicon-cog"></span>分站管理</a></li>
 <li class="active"><a href="./about.php"><span class="glyphicon glyphicon-ok"></span> 关于本程序</a> </li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>

<div class="row">
	
	<div class="col-md-12">
	<div class="panel panel-primary">
  <div class="panel-heading">关于本程序:</div>
  <div class="panel-body">
		<div class="alert alert-info alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		<strong>使用须知:</strong>本程序由阿进研发，如有冒犯请联系2474748915。
		</div>
		<div class="alert alert-info alert-dismissible" role="alert">
		<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
	后续会进行更新，修复，欢迎加入QQ群:683435694获取最新源码。

		</div>
		 </div>
</div>
	</div>
	
</div>



</div>