<?php
/**
阿进Qq2474748915
该版权死全家
**/
$mod='blank';
include("../includes/common.php");
$title='系统设置';
include './head.php';
if($islogin==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
  <nav class="navbar navbar-fixed-top navbar-default">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">导航按钮</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="./">后台管理</a>
      </div><!-- /.navbar-header -->
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          
          <li>  <a href="./"><span class="glyphicon glyphicon-user"></span> 平台首页</a>
          </li>
		  <li class="active"><a href="./set.php"><span class="glyphicon glyphicon-cog"></span> 系统设置</a></li>
 <li><a href="./sitelist.php"><span class="glyphicon glyphicon-cog"></span>分站管理</a></li>
<li><a href="./about.php"><span class="glyphicon glyphicon-ok"></span> 关于本程序</a> </li>
          <li><a href="./login.php?logout"><span class="glyphicon glyphicon-log-out"></span> 退出登陆</a></li>
        </ul>
      </div><!-- /.navbar-collapse -->
    </div><!-- /.container -->
  </nav><!-- /.navbar -->
  <div class="container" style="padding-top:70px;">
    <div class="col-xs-12 col-sm-10 col-lg-8 center-block" style="float: none;">
<?php
if(isset($_POST['submit'])) {
	$sitename=daddslashes($_POST['sitename']);
	$keywords=daddslashes($_POST['keywords']);
	$description=daddslashes($_POST['description']);
	$kfqq=daddslashes($_POST['kfqq']);
	$footer=daddslashes($_POST['footer']);
	$buy=daddslashes($_POST['buy']);
	$free=intval($_POST['free']);
	$pwd=daddslashes($_POST['pwd']);
	$sql="update `quan_config` set `sitename` ='{$sitename}',`keywords` ='{$keywords}',`description` ='{$description}',`kfqq` ='{$kfqq}',`footer` ='{$footer}',`buy` ='{$buy}',`free` ='{$free}' where `id`='{$siteid}'";
	if(!empty($pwd))$DB->query("update `quan_config` set `pwd` ='{$pwd}' where `id`='{$siteid}'");
	if($DB->query($sql))showmsg('修改成功！',1);
	else showmsg('修改失败！<br/>'.$DB->error(),4);
}else{
?>
<div class="panel panel-primary">
<div class="panel-heading"><h3 class="panel-title">系统配置</h3></div>
<div class="panel-body">
  <form action="./set.php" method="post" class="form-horizontal" role="form">
	<div class="form-group">
	  <label class="col-sm-2 control-label">网站名称</label>
	  <div class="col-sm-10"><input type="text" name="sitename" value="<?php echo $conf['sitename']; ?>" class="form-control" required/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">关键字</label>
	  <div class="col-sm-10"><input type="text" name="keywords" value="<?php echo $conf['keywords']; ?>" class="form-control" required/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">网站描述</label>
	  <div class="col-sm-10"><input type="text" name="description" value="<?php echo $conf['description']; ?>" class="form-control"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">站长ＱＱ</label>
	  <div class="col-sm-10"><input type="text" name="kfqq" value="<?php echo $conf['kfqq']; ?>" class="form-control"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">底部版权</label>
	  <div class="col-sm-10"><input type="text" name="footer" value="<?php echo $conf['footer']; ?>" class="form-control"/></div>
	</div><br/>
	<div class="form-group">
	<div class="form-group">
	  <label class="col-sm-2 control-label">号码价格</label>
	  <div class="col-sm-10"><input type="text" name="active" value="<?php echo $conf['active']; ?>" class="form-control"/></div>
	</div><br/>
		<div class="form-group">
	  <label class="col-sm-2 control-label">月租费用</label>
	  <div class="col-sm-10"><input type="text" name="buy" value="<?php echo $conf['buy']; ?>" class="form-control"/></div>
	</div><br/>
		<div class="form-group">
	  <label class="col-sm-2 control-label">一级代理</label>
	  <div class="col-sm-10"><input type="text" name="dlyi" value="<?php echo $conf['dlyi']; ?>" class="form-control"/></div>
	</div><br/>
			<div class="form-group">
	  <label class="col-sm-2 control-label">二级代理</label>
	  <div class="col-sm-10"><input type="text" name="dler" value="<?php echo $conf['dler']; ?>" class="form-control"/></div>
	</div><br/>
			<div class="form-group">
	  <label class="col-sm-2 control-label">三级代理</label>
	  <div class="col-sm-10"><input type="text" name="dlsan" value="<?php echo $conf['dlsan']; ?>" class="form-control"/></div>
	</div><br/>
	<div class="form-group">
	  <label class="col-sm-2 control-label">密码重置</label>
	  <div class="col-sm-10"><input type="text" name="pwd" value="" class="form-control" placeholder="不修改请留空"/></div>
	</div><br/>
	<div class="form-group">
	  <div class="col-sm-offset-2 col-sm-10"><input type="submit" name="submit" value="修改" class="btn btn-primary form-control"/><br/>
	 </div>
	</div>
  </form>
</div>
</div>
<script>
var items = $("select[default]");
for (i = 0; i < items.length; i++) {
	$(items[i]).val($(items[i]).attr("default"));
}
</script>
<?php
}?>

    </div>
  </div>