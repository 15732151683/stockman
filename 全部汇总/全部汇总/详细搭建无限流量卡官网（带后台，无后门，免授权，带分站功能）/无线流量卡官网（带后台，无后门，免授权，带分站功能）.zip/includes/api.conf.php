<?php
//ȦȦ�޽ӿ�API
$quan_api=array('http://quan.qqmzp.cn/quan.php?jx=','http://www.lvseba.cn/quan.php?jx=','http://www.9iqcc.com/quan.php?jx=');
