DROP TABLE IF EXISTS `quan_config`;</explode>
CREATE TABLE `quan_config` (
  `id` int(1) NOT NULL AUTO_INCREMENT,
  `switch` int(1) NOT NULL DEFAULT '1',
  `free` int(1) NOT NULL DEFAULT '0',
  `user` varchar(250) NOT NULL,
  `pwd` varchar(250) NOT NULL,
  `sitename` varchar(50) NOT NULL,
  `keywords` text NOT NULL,
  `description` text NOT NULL,
  `template` int(1) NOT NULL DEFAULT '1',
  `kfqq` varchar(20) NOT NULL,
  `qiantaibiaoyu` varchar(50) NOT NULL,
  `footer` varchar(50) NOT NULL,
  `buy` varchar(50) NOT NULL,
  `url` varchar(255) NULL,
  `date` date NULL,
  `active` INT(1) NOT NULL default '1',
  `dlyi` varchar(50) NOT NULL,
  `dler` varchar(50) NOT NULL,
  `dlsan` varchar(50) NOT NULL,
  `api` INT(1) NOT NULL default '0',
  `note` text NULL,
  `block` text DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

INSERT INTO `quan_config`(`id`, `switch`, `user`, `pwd`, `sitename`, `keywords`, `description`, `kfqq`, `footer`,`buy`, `active`, `dlyi`, `dler`, `dlsan`) VALUES
('1', '1', 'admin', '123456', '阿进网络旗下无限流量卡官网', '阿进网络旗下无限流量卡官网', '无限流量,流量卡,移动流量卡', '2474748915', '阿进网络工作室','39','20', '10', '20', '30');</explode>

DROP TABLE IF EXISTS `quan_kms`;</explode>
CREATE TABLE `quan_kms` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`kind` tinyint(1) NOT NULL DEFAULT '1',
`siteid` int(11) NOT NULL DEFAULT '0',
`km` varchar(64) NULL,
`value` int(11) NOT NULL DEFAULT '0',
`isuse` tinyint(1) DEFAULT '0',
`user` varchar(50) DEFAULT NULL,
`usetime` datetime DEFAULT NULL,
`addtime` datetime DEFAULT NULL,
 PRIMARY KEY (`id`),
  KEY (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

DROP TABLE IF EXISTS `quan_log`;</explode>
CREATE TABLE `quan_log` (
`id` int(11) NOT NULL AUTO_INCREMENT,
`siteid` int(11) NOT NULL DEFAULT '0',
`qq` varchar(20) NOT NULL,
`time` varchar(20) NOT NULL,
`km` varchar(64) NULL,
 PRIMARY KEY (`id`),
  KEY (`km`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;</explode>

DROP TABLE IF EXISTS `quan_domain`;</explode>
create table `quan_domain` (
`siteid` int(11) NOT NULL DEFAULT '1',
`domain` varchar(100) NULL,
 PRIMARY KEY (`domain`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;