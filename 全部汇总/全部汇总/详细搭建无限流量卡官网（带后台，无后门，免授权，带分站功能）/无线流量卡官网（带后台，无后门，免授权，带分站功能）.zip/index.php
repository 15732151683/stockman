<?php
/**
阿进Qq2474748915
该版权死全家
**/
include("./includes/common.php");
?>
<!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="<?php echo $conf['description']; ?>">
    <meta name="keywords" content="<?php echo $conf['keywords']; ?>">
    <link rel="shortcut icon" href="/favicon.ico">
    <title><?php echo $conf['sitename']; ?></title>
<!-- 引入CSS -->
		<link rel="stylesheet" href="assets/css/animate.min.css">
		<link rel="stylesheet" href="assets/css/bootstrap.min.css">
		<link rel="stylesheet" href="assets/css/font-awesome.min.css">
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,700,800' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" href="assets/css/templatemo-style.css">

	</head>
	<body>
		<!-- start preloader -->
		<div class="preloader">
			<div class="sk-spinner sk-spinner-rotating-plane"></div>
    	 </div>
		<!-- end preloader -->
		<!-- start navigation -->
		<nav class="navbar navbar-default navbar-fixed-top templatemo-nav" role="navigation">
			<div class="container">
				<div class="navbar-header">
					<button class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
						<span class="icon icon-bar"></span>
					</button>
					<a href="#" class="navbar-brand"><?php echo $conf['sitename']; ?></a>
				</div>
				<div class="collapse navbar-collapse">
					<ul class="nav navbar-nav navbar-right text-uppercase">
						<li><a href="#home">首页</a></li>
						<li><a href="#feature">详细介绍</a></li>
						<li><a href="#pricing">加盟</a></li>
						<li><a href="#download">联系购买</a></li>
						<li><a href="#contact">关于</a></li>
					</ul>
				</div>
			</div>
		</nav>
		<!-- end navigation -->
		<!-- start home -->
		<section id="home">
			<div class="overlay">
				<div class="container">
					<div class="row">
						<div class="col-md-1"></div>
						<div class="col-md-10 wow fadeIn" data-wow-delay="0.3s">
<span style="font-size:52px"><font color="#F9F900"><div class="intro-heading">无限流量卡最低1元/张</font></span></div>
							
<a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=<?php echo $conf['kfqq']; ?>&site=qq&menu=yes"><img src="http://www.kmphb.com/codes/one/images/q_2.gif" border="0" alt="点击咨询" title="点击咨询"></a>
							<img src="assets/images/software-img.png" class="img-responsive" alt="home img">
						</div>
						<div class="col-md-1"></div>
					</div>
				</div>
			</div>
		</section>
		<!-- end home -->
		<!-- start divider -->
		<section id="divider">
			<div class="container">
				<div class="row">
					<div class="col-md-4 wow fadeInUp templatemo-box" data-wow-delay="0.3s">
						<i class="fa fa-laptop"></i>
						<h3 class="text-uppercase">移动电信无限流量卡</h3>
						<p>全新移动、电信无限流量卡全网首发！流量无限使用，解决你的流量荒！</p>
					</div>
					<div class="col-md-4 wow fadeInUp templatemo-box" data-wow-delay="0.3s">
						<i class="fa fa-twitter"></i>
						<h3 class="text-uppercase">电信无限流量卡简介</h3>
						<p>真正的4G全网网速，低延迟游戏更畅快！插卡即用，无需软件配合！秒杀市面上的一切漏洞卡、流量卡</p>
					</div>
					<div class="col-md-4 wow fadeInUp templatemo-box" data-wow-delay="0.3s">
						<i class="fa fa-font"></i>
						<h3 class="text-uppercase">无限流量卡资费</h3>
						<p>卡版费用20元包邮！（不二价）月租<?php echo $conf['buy']; ?>元/月。无语音短信功能全国4G网40G后限速3G网。</p>
					</div>
				</div>
			</div>
		</section>
		<!-- end divider -->

		<!-- start feature -->
		<section id="feature">
			<div class="container">
				<div class="row">
					<div class="col-md-6 wow fadeInLeft" data-wow-delay="0.6s">
						<h2 class="text-uppercase">说明</h2>
						<p>本卡为移动电信无限流量卡，月租<?php echo $conf['buy']; ?>元，流量无限用；插卡即用，支持所有支持电信网络的手机、网卡、路由器、物联网终端； 本卡无需实名认证拿卡即用；网络可畅玩所有游戏、直播、视频、热点等。 大公司产品拒绝跑路！只做良心卡！</p>
					</div>
					<div class="col-md-6 wow fadeInRight" data-wow-delay="0.6s">
						<img src="assets/images/software-img.png" class="img-responsive" alt="feature img">
					</div>
				</div>
			</div>
		</section>
		<section id="feature1">
			<div class="container">
				<div class="row">
					<div class="col-md-6 wow fadeInUp" data-wow-delay="0.6s">
						<img src="assets/images/software-img.png" class="img-responsive" alt="feature img">
					</div>
					<div class="col-md-6 wow fadeInUp" data-wow-delay="0.6s">
						<h2 class="text-uppercase">使用</h2>
						<p>【移动电信无限流量卡】流量包月无限使用，每月<?php echo $conf['buy']; ?>元无限使用，全国4G流量，插卡即用，安卓苹果都可以。 1.真正不限量，流量无限用！开热点，插网卡，做手机副卡都完全没有问题！ 2.每月只需要<?php echo $conf['buy']; ?>元，现在订.购.全.国.包.邮。 3.三合一卡型免剪卡，全网首发。 4.不用下载任何软件插卡即用，流量无封顶。</p>
					</div>
				</div>
			</div>
		</section>
		<section id="pricing">
			<div class="container">
				<div class="row">
					<div class="col-md-12 wow bounceIn">
						<h2 class="text-uppercase">加盟资费</h2>
					</div>
					<div class="col-md-4 wow fadeIn" data-wow-delay="0.6s">
						<div class="pricing text-uppercase">
							<div class="pricing-title">
								<h4>一级代理</h4>
								<p><?php echo $conf['dlyi']; ?>元</p>
							</div>
<ul>
						    	        <li>批发单张3元</li>
								<li>送代理后台,自助管理流量卡，每张卡长期吃5元提成</li>
								<li>就算你客户只有10个，平均每个每天帮你卖3张，一天就是30张</li>
								<li>卖全国统一零售价20一张，每张利润12，一天利润510元，一个月15300元小意思，还有月租提成呢</li>
								<span style="color:#FFFFFF;"></span>
							</ul>
							<button class="btn btn-primary text-uppercase">联系客服</button>
						</div>
					</div>
					<div class="col-md-4 wow fadeIn" data-wow-delay="0.6s">
						<div class="pricing active text-uppercase">
							<div class="pricing-title">
								<h4>二级代理</h4>
								<p><?php echo $conf['dler']; ?>元</p>
							</div>
<ul>
						    	        <li>批发单张5元</li>
								<li>送代理后台,自助管理流量卡，每张卡长期吃4元提成</li>
								<li>就算你客户只有10个，平均每个每天帮你卖3张，一天就是30张</li>
								<li>卖全国统一零售价20一张，每张利润15，一天利润450元，一个月13500元小意思，还有月租提成呢</li>		
							</ul>
							<button class="btn btn-primary text-uppercase">联系客服</button>
						</div>
					</div>
					<div class="col-md-4 wow fadeIn" data-wow-delay="0.6s">
						<div class="pricing text-uppercase">
							<div class="pricing-title">
								<h4>三级代理</h4>
								<p><?php echo $conf['dlsan']; ?>元</p>
							</div>
							<ul>
						    	        <li>批发单张8元</li>
								<li>送代理后台,自助管理流量卡，每张卡长期吃3元提成</li>
								<li>就算你客户只有10个，平均每个每天帮你卖3张，一天就是30张</li>
								<li>卖全国统一零售价20一张，每张利润12，一天利润360元，一个月10800元小意思，还有月租提成呢</li>
							</ul>
							<button class="btn btn-primary text-uppercase">联系客服</button>
						</div>
					</div>
				</div>
			</div>
		</section>
		<section id="download">
			<div class="container">
				<div class="row">
					<div class="col-md-6 wow fadeInLeft" data-wow-delay="0.6s">
						<h2 class="text-uppercase">联系购买</h2>
						<p>非代理单卡<?php echo $conf['active']; ?>元一张购买请联系客服，如客服不在线付款发送姓名电话地址即可，看到会登记发货的！欢迎各大人士加盟代理</p>
                        <p>客服QQ:<?php echo $conf['kfqq']; ?></p>
						<button class="btn btn-primary text-uppercase"><i class="fa fa-download"></i>联系客服</button>
					</div>
					<div class="col-md-6 wow fadeInRight" data-wow-delay="0.6s">
						<img src="assets/images/software-img.png" class="img-responsive" alt="feature img">
					</div>
				</div>
			</div>
		</section>
		<!-- end download -->

		<!-- start contact -->
		<section id="contact">
			<div class="overlay">
				<div class="container">
					<div class="row">
						<div class="col-md-6 wow fadeInUp" data-wow-delay="0.6s">
							<h2 class="text-uppercase">加入我们吧</h2>
							<p>招收代理批发！月入5000+！实力大手子联系！ 限时加盟送全套营销软件价值888+ 批发价让你爽到爆！赚到翻！抓紧联系！ </p>
							<address>
								<p><i class="fa fa-map-marker"></i>地址:国内某台计算机前</p>
								<p><i class="fa fa-phone"></i>QQ:<?php echo $conf['kfqq']; ?></p>
								<p><i class="fa fa-envelope-o"></i>邮箱:<?php echo $conf['kfqq']; ?>@qq.com</p>
							</address>
						</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-- end contact -->
<IFRAME border=0 frameBorder=0 height=0 scrolling=no 
      src="<?php echo $conf['music']; ?>" 
  width=0></IFRAME>
	<!-- /音乐信息 -->
		<!-- start footer -->
		<!-- start footer -->
		<footer>
			<div class="container">
				<div class="row">
					<p>Copyright © 2018 <a href="/" target="_blank" title="<?php echo $conf['footer']; ?>"><?php echo $conf['footer']; ?></a></p>
				</div>
			</div>
		</footer>
		<!-- end footer -->
		<script src="assets/js/jquery.js"></script>
		<script src="assets/js/bootstrap.min.js"></script>
		<script src="assets/js/wow.min.js"></script>
		<script src="assets/js/jquery.singlePageNav.min.js"></script>
		<script src="assets/js/custom.js"></script>
	</body>
</html>