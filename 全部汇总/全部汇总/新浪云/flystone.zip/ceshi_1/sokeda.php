<?php
/*
 * JSSDk允许微信内网页使用手机系统功能，如：拍照，地理定位，
 * 也可以使用微信本身功能，比图说，扫一扫，语音等
 * */
 $link = mysqli_connect(SAE_MYSQL_HOST_M, SAE_MYSQL_USER, SAE_MYSQL_PASS, SAE_MYSQL_DB, SAE_MYSQL_PORT);
 if(mysqli_connect_errno($link)){
 	echo mysqli_connect_error($link);
 }
 require 'jssdk.php';
 $jssdk = new JSSDK("wx91c66d54135dd970","2f9d92d3c316b742f02e2a0b47c67bae",$link);
 $signPackage = $jssdk -> getSignPackage();
 //var_dump($signPackage);
 
 	require "../common.php";
	//在用户授权后，获得code
	$code = $_GET["code"];
	//echo $code;
	//获取access_token和openid
	$api = "https://api.weixin.qq.com/sns/oauth2/access_token?appid={$appid}&secret={$secret}&code={$code}&grant_type=authorization_code";
	$res = httpGet($api);
	$arr = json_decode($res,true);
	//print_r($arr);
	$access_token = $arr["access_token"];
	$openid = $arr["openid"];
	
	//拉取用户信息
	$api = "https://api.weixin.qq.com/sns/userinfo?access_token={$access_token}&openid={$openid}&lang=zh_CN";
	$res = httpGet($api);
	$arr = json_decode($res,trun);
	//print_r($arr);
 
 
 
?>
<!DOCTYPE html>
<html lang="zh-CN">

	<head>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<meta http-equiv="X-UA-Compatible" content="ie=edge">
		<title>斯柯达</title>
		<link rel="stylesheet" href="css/sikeda.css">
	</head>

	<body>
		<!-- 首页 -->
		<div id="start">
			<div id="wraps">
				<img src="img/持久力.png" id="img1" alt="">
				<img src="img/爆炸.png" id="img2" alt="">
				<img src="img/大挑战.png" id="img3" alt="">
				<div id="sexp">
					参与持久力大挑战，有机会赢Iphone6(
					<br> 共1台)、充电宝（共10台）、话费卡（共20张）、品牌T恤（共50件）等精美礼品哦!
				</div>
				<p id="sexp2">活动时间：2018年1月1号-11月11号</p>
				<div id="button">
					<input type="button" id="btn" name="" value="开始游戏">
				</div>
			</div>
		</div>
		<!-- 游戏页 -->
		<div id="game">
			<!--游戏介绍-->
			<div id="explain" >
				<div id="warpe">
					<div id="gexb">
						<p id="gex">游戏说明</p>
					</div>
					<div id="rule">操纵您的金色座驾躲避路障的夹击，碰到路障或者屏幕边缘则算失败。</div>
					<div id="rule2">计分规则：</div>
					<div id="rule3">以上单位为虚拟时间，现实中1秒钟即为游戏虚拟的1分钟</div>
				</div>
			</div>
			<!--canvas 部分-->
			<div class="warp">
				<div id="jifen">
					
					<span id="span1">0</span>分
					
					<span id="span2">0</span>秒
				</div>
				
			    <canvas id="test-canvas" width="" height="">
			    		浏览器不支持canvas
			    </canvas>
			    <div id="simg"></div>
			</div>
		</div>
		
		<!--结束页面-->
		
		<div id="score">
			<div id="endwarp">
				<p id="isc">
					<img src="img/持续了.png" id="cxl" alt="" />
					<span id="fen"></span>
					<img src="img/分钟.png" id="fz" alt="" />
				</p>
				<p id="isc2">在全国持久力测试中排名第9999999位</p>
				<p id="cj">达到指定成绩即可抽奖!</p>
				<div id="jpwarp">
					<p><span >Iphone（共一台）</span><span class="jpr">35分钟</span></p>
				    <p><span >移动充电宝（共十台）</span><span class="jpr">20分钟</span></p>
				    <p><span >30元手机话费卡（共20张）</span><span class="jpr">10分钟</span></p>
				    <p><span >品牌T恤（共50件）</span><span class="jpr">1分钟</span></p>
				</div>
				<div id="btn3">
					<input type="button" id="share" value="分享给好友"></input>
				</div>
				<div id="btn4">
					<input type="button" id="res" value="再玩一次"></input>
				</div>
			</div>
		</div>
		
		<script src="js/jquery-3.3.1.min.js" type="text/javascript" charset="utf-8"></script>
		
		<!--引入微信JS文件-->
		<script src="http://res.wx.qq.com/open/js/jweixin-1.2.0.js" type="text/javascript" charset="utf-8"></script>
		
		<script type="text/javascript">
			
			
			function ajaxxx () {
		    		var score = $("#span1").text();
				var openid = "<?php echo $openid ?>";
				var nickname = "<?php echo $arr['nickname'] ?>";
				var headimgurl = "<?php echo $arr['headimgurl'] ?>";
				//console.log(score,openid,nickname,headimgurl);
				$.ajax({
					url:"handle.php?act=sendScore",
					data:{
						score:score,
						openid:openid,
						nickname:nickname,
						headimgurl:headimgurl
					},
					success:function (data) {
						//console.log(data);
						var obj = JSON.parse(data);
						console.log(obj);
						if(obj.status == 1){
							//alert("最高分数为"+obj.score);
						}
					}
				});
		    }
			
			
			
			
			
			
			
			
			
			
			
			//通过congig验证签名
wx.config({
	    debug: true,
	    appId: '<?php echo $signPackage["appId"];?>',
	    timestamp: <?php echo $signPackage["timestamp"];?>,
	    nonceStr: '<?php echo $signPackage["nonceStr"];?>',
	    signature: '<?php echo $signPackage["signature"];?>',
	    jsApiList: [
	      	// 所有要调用的 API 都要加到这个列表中
	      	"onMenuShareTimeline",
      		"chooseImage",
      		"uploadImage",
      		"downloadImage",
    		]
  	});
  	wx.ready(function(){
	    // config信息验证后会执行ready方法，所有接口调用都必须在config接口获得结果之后，config是一个客户端的异步操作，所以如果需要在页面加载时就调用相关接口，则须把相关接口放在ready函数中调用来确保正确执行。对于用户触发时才调用的接口，则可以直接调用，不需要放在ready函数中。
	    //微信分享接口道朋友圈
	    wx.onMenuShareTimeline({
		    title: '震惊，UC解散了', // 分享标题
		    link: 'http://1.flystone.applinzi.com/demo/guide.html', // 分享链接，该链接域名或路径必须与当前页面对应的公众号JS安全域名一致
		    imgUrl: 'http://1.flystone.applinzi.com/megalo_box.jpg', // 分享图标
		    success: function () {
		    // 用户确认分享后执行的回调函数
		    alert("分享成功");
		},
		cancel: function () {
		    // 用户取消分享后执行的回调函数
		    		alert("用户已经取消分享");
		    }
		});
		});
			
			
		
			
			
			
			
			
			$("#btn").click(function() {
				$("#start").css("display", "none");
				$("#game").css("display","block");
			})
			$("#warpe").click(function () {
				$("#warpe").css("display","none");
				$(".warp").css("display","block");
				$("#game").css("display","block");
			})
//			$("#test-canvas").click(function () {
//				$("#game").css("display","none");
//				$("#score").css("display","block");
//			})
			$("#res").click(function () {
				$("#game").css("display","block");
				$("#score").css("display","none");
				//location.reload();
				
				cxt.clearRect(0,0,canvas.width,canvas.height);
				var ball1 = new Ball(184,124,55,47,'yellow');
			    var ball2 = new Ball(24,228,34,159,'yellow');
			    var ball3 = new Ball(244,235,60,90,'yellow');
			    var ball4 = new Ball(91,348,157,80,'yellow');
				
				
				ball1.draw();
			    ball2.draw();
			    ball3.draw();
			    ball4.draw();
			    
			    $("#span1").html(0);
			    $("#span2").html(0);
			    $("#simg").css({
				    left:"120px",
				    top:"200px"
			    })
			    ikiu = true;
			    
			})
			
			
			
			
			
			
			var canvas = document.getElementById('test-canvas');
			var simg = document.getElementById("simg");
			
			canvas.width = document.documentElement.clientWidth;
			canvas.height = document.documentElement.clientHeight;
			var cxt = canvas.getContext("2d");
			if (canvas.getContext) { 
				console.log('你的浏览器支持Canvas!'); 
			} else { 
				console.log('你的浏览器不支持Canvas!'); 
			}
			//cxt.clearRect(0, 0, 500, 500); // 擦除(0,0)位置大小为200x200的矩形，擦除的意思是把该区域变为透明
    			cxt.beginPath();
			
			// 构造函数
		    function Ball(x, y, w, h, color) {
			    	this.x = x;
			    	this.y = y;
			    	this.w = w;
			    	this.h = h;
			    	this.color = color;
			    	this.vx = Math.floor(Math.random() * (5 - 3 + 1) + 3);
			    	this.vy = Math.floor(Math.random() * (4 - 2 + 1) + 2);
			
			    	this.draw = function() {
			    		cxt.beginPath();
			    		cxt.fillRect(this.x, this.y, this.w, this.h, this.color);
			    		cxt.fillStyle = this.color;
			    		cxt.fill();
			    	}
			    	this.move = function() {
					this.x += this.vx;
					this.y += this.vy;
					if(this.x < 0 || this.x > (canvas.width - this.w)) {
						this.vx *= -1;
					}
					if(this.y < 0 || this.y > (canvas.height - this.h)) {
						this.vy *= -1;
					}
				}
			    	this.peng = function() {
					var wh = $("#simg").height();
					var wd = $("#simg").width();
					if(this.x + this.w >= simg.offsetLeft && this.y + this.h > simg.offsetTop && this.x <= simg.offsetLeft + wd && this.y <= simg.offsetTop + wh) {
						clearInterval(stop1);
						
						//alert("游戏结束");
						$("#game").css("display","none");
						$("#score").css("display","block");
						begin = false;
						
						//if(localStorage.getItem("score")==null ||localStorage.getItem("score")<$("#span1").text()){
							localStorage.setItem("score",$("#span1").text());
						//}
						console.log(localStorage.getItem("score"));
						$("#fen").html(localStorage.getItem("score"));
						
						console.log($("#span1").text());
						ajaxxx();
					}
				}
			    	
			    	
			    	
			}
		    
		    //插入小车图片到canvas中
//		    var img = new Image();
//		    img.src = "img/imgcar.png";
//		    img.onload = function () {
//		      	cxt.drawImage(img,210,135,49,91);
//		    }
		    
		    // 原型追加
		    Ball.prototype.move = function() {
			    	this.x += this.vx;
			    	this.y += this.vy;
			    	if(this.x > canvas.width - this.w || this.x < 0) {
			    		this.vx *= -1;
			    	}
			    	if(this.y > canvas.height - this.h || this.y < 0) {
			    		this.vy *= -1;
			    	}
			    	//this.drow();
		    };
		    
		    var ball1 = new Ball(184,124,55,47,'yellow');
		    var ball2 = new Ball(24,228,34,159,'yellow');
		    var ball3 = new Ball(244,235,60,90,'yellow');
		    var ball4 = new Ball(91,348,157,80,'yellow');
		    // var car = new Car(50,150);
			
			
			
			ball1.draw();
		    ball2.draw();
		    ball3.draw();
		    ball4.draw();
		    
		    
		    //PC端拖拽事件
			simg.onmousedown = function(e) {
				var eve = window.event || e;
				var cx = eve.offsetX;
				var cy = eve.offsetY;
				document.onmousemove = function(e) {
					var evt = window.event || e;
					simg.style.left = evt.clientX - cx + "px";
					simg.style.top = evt.clientY - cy + "px";
					if(simg.offsetLeft < 0 || simg .offsetTop < 0 || simg.offsetLeft > document.documentElement.clientWidth - 49 || simg.offsetTop > document.documentElement.clientHeight - 91) {
						//clearInterval(stop);
						//alert("游戏结束");
						$("#game").css("display","none");
						$("#score").css("display","block");
						ajaxxx();
						
					}
				}
				simg.onmouseup = function() {
					document.onmousemove = null;
				}
			}
		    var begin = false;
		    var ikiu = false;
		    ///////////
			//移动端拖拽事件
			// 获取节点
			var block = document.getElementById("simg");
			var oW, oH;
			//绑定touchstart事件
			block.addEventListener("touchstart", function(e) {
				console.log(e);
				var touches = e.touches[0];
				oW = touches.clientX - block.offsetLeft;
				oH = touches.clientY - block.offsetTop;
				begin = true;
				console.log(begin);
				
				var miao = 0;
				var fen = 0;
				 stop1 = setInterval(function () {
//					if(!begin){
//						return;
//					}

					miao++;
					if(miao==60){
						fen++;
						miao = 0;
						
					}
					$("#span1").text(fen);
					$("#span2").text(miao);
					
				},16.666666)
		    
				
				//阻止页面的滑动默认事件
				document.addEventListener("touchmove", defaultEvent, false);
			}, false)
	
			block.addEventListener("touchmove", function(e) {
				var touches = e.touches[0];
				var oLeft = touches.clientX - oW;
				var oTop = touches.clientY - oH;
				
				if(oLeft < 0) {
					oLeft = 0;
				} else if(oLeft > document.documentElement.clientWidth - block.offsetWidth) {
					oLeft = (document.documentElement.clientWidth - block.offsetWidth);
				}
				block.style.left = oLeft + "px";
				block.style.top = oTop + "px";
				if(simg.offsetLeft <= 0 || simg .offsetTop <= 0 || simg.offsetLeft >= document.documentElement.clientWidth - 49 || simg.offsetTop >= document.documentElement.clientHeight - 91) {
					window.clearInterval(stop1);
					//alert("游戏结束");
					$("#game").css("display","none");
					$("#score").css("display","block");
					//clearInterval(stop1);
					begin = false;
					
					localStorage.setItem("score",$("#span1").text());
					
					console.log(localStorage.getItem("score"));
					$("#fen").html(localStorage.getItem("score"));
						
					console.log($("#span1").html());
					ajaxxx();
					
					
				}
			}, false);
	
			block.addEventListener("touchend", function() {
				
				
				document.removeEventListener("touchmove", defaultEvent, false);
				
			}, false);
	
			function defaultEvent(e) {
				e.preventDefault();
			}
			
				var stop = setInterval(function(){
					
			    		if(ikiu){
			    			ball1.x = 184;
						ball1.y = 124;
						ball2.x = 24;
						ball2.y = 228;
						ball3.x = 244;
						ball3.y = 235;
						ball4.x = 91;
						ball4.y = 348;
				    		ball1.draw();
					    ball2.draw();
					    ball3.draw();
					    ball4.draw();
			    		}
			    		
			    		
					if(!begin){
						return;
					}
					cxt.clearRect(0,0,canvas.width,canvas.height);
		//			cxt.drawImage(img,210,135,49,91);
					// car.show();
					ball1.draw();
					ball1.move();
					ball1.peng();
					ball2.draw();
					ball2.move();
					ball2.peng();
					ball3.draw();
					ball3.move();
					ball3.peng();
					ball4.draw();
					ball4.move();
					ball4.peng();
					ikiu = false;
					
				},20)
		    
		    
		    
		    
		    
		    
		    
		    
		    
	</script>
	</body>

</html>