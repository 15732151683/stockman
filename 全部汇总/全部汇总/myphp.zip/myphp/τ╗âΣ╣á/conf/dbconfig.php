<?php
//数据库的配置文件
$host = "127.0.0.1";
$user = "root";
$password = "";
$database = "register";
?>