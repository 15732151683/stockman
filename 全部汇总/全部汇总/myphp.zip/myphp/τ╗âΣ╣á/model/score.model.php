<?php
class ScoreModel extends Model{
	protected $table = "score";
	
}
?>