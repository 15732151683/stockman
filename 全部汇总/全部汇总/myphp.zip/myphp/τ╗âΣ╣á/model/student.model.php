<?php
//学生表数据模型
class StudentModel extends Model{
	protected $table = "regfrm";
}
?>