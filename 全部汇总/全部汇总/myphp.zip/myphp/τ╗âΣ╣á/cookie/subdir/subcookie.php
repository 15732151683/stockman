<?php
setcookie("password",123456);
var_dump($_COOKIE);

?>