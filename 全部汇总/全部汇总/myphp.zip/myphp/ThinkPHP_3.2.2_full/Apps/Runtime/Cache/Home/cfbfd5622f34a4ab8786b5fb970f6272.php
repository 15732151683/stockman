<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title></title>
	</head>
	<body>
		<form action="" method="post">
		用户名:<input type="text" name="username" id="username" value=""><br />
		密码: <input type="password" name="password" id="password" value="" /><br />
		<input type="submit" value="立即登录"/>
	</form>
	</body>
</html>