<?php
	namespace Home\Model;
	use Think\Model;
	class StudentModel extends Model{
		//模型对应的表名
		protected $tableName = "regfrm"; 
	}
?>