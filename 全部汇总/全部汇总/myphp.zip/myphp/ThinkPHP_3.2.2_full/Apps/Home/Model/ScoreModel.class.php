<?php
	namespace Home\Model;
	use Think\Model;
	class ScoreModel extends Model{
		//模型对应的表名
		protected $tableName = "score"; 
	}
?>